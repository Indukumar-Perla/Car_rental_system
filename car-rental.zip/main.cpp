#include <iostream>
#include <string.h>

using namespace std;
class details 
{
    public:
int main()
{
    int n;
    cout << "         WELCOME TO CAR RENTALS       " << endl;
    cout << "1. To rent a car " << endl;
    cout << "2. To rent your car " << endl;
    cout << "select your choice : ";
    cin >> n;
    if(n=1)
    {
        cout << " To rent a car " << endl;
        cout << "     Rules     " << endl;
        cout << "I.If any damage happens to car you are responsible for it  " << endl;
        cout << "II. please pay the advance amount for surity before renting a car " << endl;
        cout << "III. We are not responsible for petrol in car please check it befor renting it " << endl;
        cout << "IV. plese mention your details in below coloumn (all are compulsory)" << endl;
        cout << " Drive safe and be safe " << endl; 
        details detobj1
        char name;
        int date;
        char cc[15];
        char model[5];
        string dl[10];
        int rent;
        int nod;
        int tr;
        cout << " enter the name of person renting a car : ";
        cin >> name;
        cout << " enter the date when they are renting a car : ";
        cin >> date;
        cout << " enter the company of renting a car : ";
        cin >> cc;
        cout << " enter the car model  of renting a car : ";
        cin >> model;
        cout << " enter the driving lisence details of  person : ";
        cin >> dl;
        cout << " Rent per day : ";
        cin >> rent;
        cout << " enter the number of days that your renting a car : ";
        cin >> nod;
        tr= nod * rent;
        cout << " total estimated rent is  : ";
        cin >> tr;
        cout << name << "";
        cout << date << "";
        cout << cc << "";
        cout << model << "";
        cout << dl << "";
        cout << rent << "";
        cout << nod << "";
        cout << tr << "";
    };
else if (n=2)
{
    int m; 
        cout << " To rent your car " << endl;
        cout << "     Rules     " << endl;
        cout << "I.There shouldn't be any damage to car " << endl;
        cout << "II. All the paper and proofs must be original " << endl;
        cout << "III. no fines should be on car " << endl;
        cout << "IV. plese mention your details in below coloumn (all are compulsory)" << endl;
        cout << " clearly mention that you want to sell your car or rent it " << endl; 
        cout << " 3. sell " << endl;
        cout << " 4. rent " << endl;
        cout << " select your choice : ";
        cin >> m;
        if(m=3)
        {
            
        details detobj2
        
        char Name[50];
        int Date;
        char Cc[15];
        char model[5];
        int amount;
        cout << " enter the name of person selling a car : ";
        cin >> Name;
        cout << " enter the date when they are sold the  car : ";
        cin >> Date;
        cout << " enter the company of selling a car : ";
        cin >> Cc;
        cout << " enter the car model  of selling a car : ";
        cin >> model;
        cout << " enter the amount expected : ";
        cin >> amount;
        cout << Name;
        cout << Date;
        cout << Cc;
        cout << model;
        cout << amount;
    }
    if(m=4)
    class dt:public class details
    {
        dt.name
        dt.date
        dt.cc
        dt.model
        dt.rent
        cout << " enter the name of person renting a car : ";
        cin >> name;
        cout << " enter the date when they are renting a car : ";
        cin >> date;
        cout << " enter the company of renting a car : ";
        cin >> cc;
        cout << " enter the car model  of renting a car : ";
        cin >> model;
        cout << " enter the driving lisence details of  person : ";
        cin >> dl;
        cout << " Rent per day : ";
        cin >> rent;
    }
}
return 0;
}

